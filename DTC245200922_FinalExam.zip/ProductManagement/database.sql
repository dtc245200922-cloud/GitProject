CREATE DATABASE IF NOT EXISTS product_management;
USE product_management;

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    price DOUBLE NOT NULL,
    quantity INT NOT NULL
);

INSERT INTO products (name, price, quantity) VALUES 
('Laptop Dell XPS 15', 1500.00, 10),
('Chuột Logitech G502', 50.00, 50);