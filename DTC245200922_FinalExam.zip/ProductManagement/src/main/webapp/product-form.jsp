<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Quản lý Sản Phẩm</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input[type="text"], input[type="number"] { width: 300px; padding: 8px; }
        button { padding: 10px 15px; background-color: #007bff; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h2>
        <c:if test="${product != null}">Cập Nhật Sản Phẩm</c:if>
        <c:if test="${product == null}">Thêm Sản Phẩm Mới</c:if>
    </h2>
    <form action="<c:if test='${product != null}'>update</c:if><c:if test='${product == null}'>insert</c:if>" method="post">
        <c:if test="${product != null}">
            <input type="hidden" name="id" value="<c:out value='${product.id}' />" />
        </c:if>
        
        <div class="form-group">
            <label>Tên Sản Phẩm:</label>
            <input type="text" name="name" value="<c:out value='${product.name}' />" required />
        </div>
        <div class="form-group">
            <label>Giá (VNĐ/USD):</label>
            <input type="number" step="0.01" name="price" value="<c:out value='${product.price}' />" required />
        </div>
        <div class="form-group">
            <label>Số Lượng:</label>
            <input type="number" name="quantity" value="<c:out value='${product.quantity}' />" required />
        </div>
        <button type="submit">Lưu</button>
        <a href="list" style="margin-left: 10px;">Hủy</a>
    </form>
</body>
</html>